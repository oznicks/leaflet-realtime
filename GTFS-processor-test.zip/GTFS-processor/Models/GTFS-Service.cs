﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GTFS_processor.Models
{
    public class GTFS_Service
    {
        public string route_id { get; set; }
        public string service_id { get; set; }
        public double latitude { get; set; }
        public double longitude { get; set; }
    }
}
