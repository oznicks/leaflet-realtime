﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Net.WebSockets;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Threading;
using GTFS_processor.Repositories;

namespace GTFS_processor.Controllers
{
    [Route("api/[controller]")]
    public class GTFSParseController : Controller
    {
        private readonly IGTFSParseRepository _repository;

        public GTFSParseController(HttpContext context, IGTFSParseRepository repository)
        {
            _repository = repository;
        }
        // GET api/values
        [HttpGet]
        public async Task Get()
        {
            var context = ControllerContext.HttpContext;
            var isSocketRequest = context.WebSockets.IsWebSocketRequest;

            if (isSocketRequest)
            {
                WebSocket webSocket = await context.WebSockets.AcceptWebSocketAsync();
                await _repository.GetMessages(context, webSocket);
            }
            else
            {
                context.Response.StatusCode = 400;
            }
        }
    }
}